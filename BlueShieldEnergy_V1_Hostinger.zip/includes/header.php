<?php
if (!isset($page_title)) $page_title = "Blue Shield Energy | Powering Your Future";
$current_page = basename($_SERVER["PHP_SELF"] ?? "index.php");
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#071b48">
  <meta name="description" content="Blue Shield Energy provides residential, commercial and industrial solar services, equipment supply, commissioning and maintenance in Ahmedabad, Gujarat.">
  <title><?= htmlspecialchars($page_title, ENT_QUOTES, "UTF-8") ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>
<div class="topbar"><div class="container topbar-inner"><span>Solar solutions for homes, businesses & industry</span><div><a href="mailto:jaymit@blueshieldenergy.in">jaymit@blueshieldenergy.in</a><span class="top-separator">|</span><a href="tel:+919601286531">+91 96012 86531</a></div></div></div>
<header class="site-header"><div class="container nav-wrap">
  <a class="brand" href="index.php" aria-label="Blue Shield Energy home">
    <span class="brand-mark"><span class="brand-mark-inner">BS</span></span><span class="brand-words"><strong>BLUE SHIELD</strong><b>ENERGY</b><small>Powering Your Future</small></span>
  </a>
  <button class="nav-toggle" aria-label="Open navigation" aria-expanded="false"><span></span><span></span><span></span></button>
  <nav class="main-nav" aria-label="Main navigation"><a class="<?= $current_page==='index.php'?'active':'' ?>" href="index.php">Home</a><a class="<?= $current_page==='services.php'?'active':'' ?>" href="services.php">Services</a><a href="index.php#process">Our process</a><a class="<?= $current_page==='about.php'?'active':'' ?>" href="about.php">About</a><a class="<?= $current_page==='contact.php'?'active':'' ?>" href="contact.php">Contact</a><a class="nav-cta" href="contact.php">Get a proposal <span>↗</span></a></nav>
</div></header>