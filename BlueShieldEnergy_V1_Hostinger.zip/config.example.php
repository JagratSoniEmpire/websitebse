<?php
// Copy this file to config.php and replace the placeholders with your Hostinger MySQL details.
// Keep config.php private; never publish database credentials.
return [
  "host" => "localhost",
  "database" => "YOUR_DATABASE_NAME",
  "username" => "YOUR_DATABASE_USER",
  "password" => "YOUR_DATABASE_PASSWORD"
];
